package teamsTech;

import program.IProgram;
import program.Program;

public class TeamsTech {

	// main method
	public static void main(String[] args) {

		IProgram teamsTeach = new Program();// Initialise program
		teamsTeach.start(); // start program

	}

}
