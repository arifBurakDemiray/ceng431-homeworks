package program;

public interface IProgram {
	
	/**
	 * @author Furkan Sahin - 250201042
	 * @author Arif Burak Demiray - 250201022 
	 * This function starts the TeamsTeach program
	 */
	void start();
}
