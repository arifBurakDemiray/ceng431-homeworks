package user;

import team.Team;
public interface ITeamOwner {

	void assignNewTeamOwner(Academician academician,Team team);
}
