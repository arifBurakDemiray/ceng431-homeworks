package enums;

public enum TimePeriod {
	AM,PM;
}
