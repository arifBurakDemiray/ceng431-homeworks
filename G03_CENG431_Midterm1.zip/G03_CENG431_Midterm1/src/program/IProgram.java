package program;

public interface IProgram {
	void start();
}
