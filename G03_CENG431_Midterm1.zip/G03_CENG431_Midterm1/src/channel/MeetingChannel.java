package channel;


public class MeetingChannel extends Channel {

	public MeetingChannel(Meeting meeting,String name) {
		super(meeting,name);
		// TODO Auto-generated constructor stub
	}

	

}
