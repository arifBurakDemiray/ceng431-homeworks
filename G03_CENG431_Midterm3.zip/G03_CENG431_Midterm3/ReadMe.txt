You can reach every user's username and password through the users.xml file.

Users' collections, followers, followings and outfits' comments, number of likes, number of dislikes are not filled by us. 
You can log in and can do waht process you want. 
After each process you do, data of users.xml, outfits.json, likes.json and dislikes.json are updated automatically.
To sum up, users' collections, followers, followings, liked outfits, disliked outfits and outfits' comments, number of likes, number of dislikes 
are updated in the files automatically after you do processes.

