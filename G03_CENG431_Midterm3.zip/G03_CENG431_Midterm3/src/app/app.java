package app;

public class app {

	public static void main(String[] args) throws Exception  {
		Startup startup = new Startup();
		startup.run();
	
	}
}

