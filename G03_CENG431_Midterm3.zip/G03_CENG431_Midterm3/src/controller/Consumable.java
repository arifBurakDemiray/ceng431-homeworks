package controller;

/**
 * This class is for consuming warnings
 */
public class Consumable {
	public Consumable() {

	}

	/**
	 * This function consumes not used warning
	 */
	public void supressNotUsed() {
	}
}