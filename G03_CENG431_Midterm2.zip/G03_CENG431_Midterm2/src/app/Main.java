package app;


import view.AppView;
import view.View;

public class Main {
	public static void main(String[] args) throws Exception {
		View view = new AppView();
		view.start();
	}
}
