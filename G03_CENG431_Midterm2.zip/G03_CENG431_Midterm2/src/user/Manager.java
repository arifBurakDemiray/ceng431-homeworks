package user;

public class Manager extends User{

	public Manager(String userName, String password) {
		super(userName, password);
	}

}
