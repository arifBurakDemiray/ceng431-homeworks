package user;

public class Admin extends User {

	public Admin(String userName, String password) {
		super(userName, password);
	}

}
