ADMIN LOGIN : 

Username : SYSADMIN
Password : SYSADMIN